// app/start/add-players.tsx
import { useState } from "react";
import { View, Text, FlatList, StyleSheet, Pressable } from "react-native";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { useRoundDraft } from "@/store/useRoundDraft";
import { Link } from "expo-router";
import { v4 as uuidv4 } from "uuid";

export default function AddPlayers() {
  const [name, setName] = useState("");
  const { players, addPlayer, removePlayer } = useRoundDraft();

  const onAdd = () => {
    const n = name.trim();
    if (!n) return;
    addPlayer({ id: uuidv4(), name: n });
    setName("");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Add Players</Text>

      <Input placeholder="Player name" value={name} onChangeText={setName} />
      <View style={styles.inlineBtns}>
        <Button onPress={onAdd}>Add</Button>
      </View>

      <FlatList
        contentContainerStyle={{ paddingTop: 8, paddingBottom: 100 }}
        data={players}
        keyExtractor={(p) => p.id}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <Text style={styles.playerName}>{item.name}</Text>
            <Pressable onPress={() => removePlayer(item.id)}>
              <Text style={styles.remove}>Remove</Text>
            </Pressable>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>No players yet.</Text>}
      />

      <View style={styles.footer}>
        <Link href="/start" asChild>
          <Button disabled={players.length === 0}>Continue</Button>
        </Link>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F7F7F7",
    paddingHorizontal: 24,
    paddingTop: 16,
  },
  header: {
    fontSize: 20,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 12,
  },
  inlineBtns: { marginTop: 10, marginBottom: 16, width: "100%" },
  row: {
    backgroundColor: "#fff",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    padding: 14,
    marginBottom: 8,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  playerName: { color: "#111827", fontWeight: "500" },
  remove: { color: "#DC2626", fontWeight: "600" },
  empty: { color: "#6B7280", marginTop: 12 },
  footer: { position: "absolute", left: 24, right: 24, bottom: 20 },
});
