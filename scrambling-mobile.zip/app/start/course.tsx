// app/start/course.tsx
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { useRoundDraft } from "@/store/useRoundDraft";
import { searchCourses } from "@/lib/api/courses";

const USE_MOCK = false; // set true to bypass backend while styling
const mock = [
  { id: "1", name: "Mount Diablo GC", city: "Danville" },
  { id: "2", name: "Hidden Oaks", city: "Walnut Creek" },
];

export default function CourseSelect() {
  const [q, setQ] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const { course, setCourse } = useRoundDraft();

  const debouncedRef = useRef<NodeJS.Timeout | null>(null);

  const doSearch = useCallback(async (term: string) => {
    if (!term || term.length < 2) {
      setResults([]);
      setErr(null);
      return;
    }
    setLoading(true);
    setErr(null);
    try {
      if (USE_MOCK) {
        await new Promise((r) => setTimeout(r, 250));
        setResults(
          mock.filter((c) => c.name.toLowerCase().includes(term.toLowerCase()))
        );
      } else {
        const data = await searchCourses(term);
        setResults(Array.isArray(data) ? data : []);
      }
    } catch (e: any) {
      setErr(e?.message ?? "Search failed");
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (debouncedRef.current) clearTimeout(debouncedRef.current);
    debouncedRef.current = setTimeout(() => doSearch(q), 300);
    return () => {
      if (debouncedRef.current) clearTimeout(debouncedRef.current);
    };
  }, [q, doSearch]);

  const selectedId = course?.id;

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Find a Course</Text>

      <Input
        placeholder="Search by course name, city…"
        value={q}
        onChangeText={setQ}
      />

      {err && <Text style={styles.error}>{err}</Text>}
      {loading && (
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      )}

      {!loading && !err && results.length === 0 && q.length >= 2 && (
        <Text style={styles.empty}>No results for “{q}”.</Text>
      )}

      <FlatList
        contentContainerStyle={{ paddingTop: 8, paddingBottom: 100 }}
        data={results}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item }) => {
          const isSelected =
            selectedId && String(selectedId) === String(item.id);
          return (
            <Pressable
              onPress={() =>
                setCourse({ id: String(item.id), name: item.name })
              }
              style={[styles.card, isSelected && styles.cardSelected]}
            >
              <View>
                <Text style={styles.courseName}>{item.name}</Text>
                {item.city ? (
                  <Text style={styles.courseCity}>{item.city}</Text>
                ) : null}
              </View>
              {isSelected ? (
                <Text style={styles.selected}>Selected</Text>
              ) : null}
            </Pressable>
          );
        }}
      />

      <View style={styles.footer}>
        <Button disabled={!selectedId}>Continue</Button>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F7F7F7",
    paddingHorizontal: 24,
    paddingTop: 16,
  },
  header: {
    fontSize: 20,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 12,
  },
  error: { color: "#DC2626", marginTop: 8 },
  loading: { marginTop: 12 },
  empty: { color: "#6B7280", marginTop: 12 },
  card: {
    backgroundColor: "#fff",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    padding: 14,
    marginBottom: 8,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  cardSelected: { borderColor: "#00C853" },
  courseName: { color: "#111827", fontWeight: "600" },
  courseCity: { color: "#6B7280" },
  selected: { color: "#00C853", fontWeight: "700" },
  footer: { position: "absolute", left: 24, right: 24, bottom: 20 },
});
